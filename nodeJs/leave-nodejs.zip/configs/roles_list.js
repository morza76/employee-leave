const ROLES_LIST = {
    Admin: 1001,
    User: 1000,
  };
  
  module.exports = ROLES_LIST;