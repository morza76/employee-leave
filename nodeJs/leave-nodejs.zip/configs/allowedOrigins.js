const allowedOrigins = [
    "http://localhost:3000",
    "http://localhost:3030",
    "http://localhost:3500",
    "https://www.mysite.com",
  ];
  
  module.exports = allowedOrigins;